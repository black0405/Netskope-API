"""
auth.py
=======
Interactive SSO authentication and session persistence.

Strategy
--------
Arbitrary SSO flows (Okta, Azure AD, Google, PingFederate, ...) are hard to
script reliably and doing so would amount to fighting the identity provider.
Instead we open a *visible* browser, let you log in by hand exactly as you
normally would, then capture the resulting authenticated ``storage_state``
(cookies + localStorage). Every later run reuses that state headlessly, so you
only log in when the session actually expires.

No credentials are ever read, stored, or transmitted by this program.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

from playwright.async_api import BrowserContext, async_playwright

from .config import Settings
from .logging_setup import get_logger

log = get_logger("auth")


async def _looks_authenticated(context: BrowserContext, settings: Settings) -> bool:
    """Heuristic: can we load a docs page without being bounced to a login URL?"""
    page = await context.new_page()
    try:
        await page.goto(
            settings.base_url,
            wait_until="domcontentloaded",
            timeout=settings.nav_timeout_ms,
        )
        # Give any client-side auth redirect a moment to fire.
        await page.wait_for_timeout(2500)
        current = page.url.lower()
        for marker in ("login", "signin", "sign-in", "sso", "auth0", "okta", "microsoftonline"):
            if marker in current:
                log.debug("Auth check landed on %s -> not authenticated", current)
                return False
        return True
    except Exception as exc:  # noqa: BLE001
        log.debug("Auth check failed: %s", exc)
        return False
    finally:
        await page.close()


async def ensure_session(settings: Settings, force: bool = False) -> Path:
    """
    Ensure a valid ``storage_state.json`` exists, launching an interactive
    login if necessary. Returns the path to the storage state file.
    """
    settings.ensure_dirs()
    state_path = settings.storage_state_path

    if state_path.exists() and not force:
        # Validate the existing session headlessly before trusting it.
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**settings.launch_kwargs(headless=True))
            context = await browser.new_context(
                storage_state=str(state_path),
                user_agent=settings.user_agent,
                viewport={"width": settings.viewport_width, "height": settings.viewport_height},
            )
            ok = await _looks_authenticated(context, settings)
            await context.close()
            await browser.close()
        if ok:
            log.info("Reusing saved session: %s", state_path)
            return state_path
        log.warning("Saved session appears expired -- re-authenticating.")

    await _interactive_login(settings, state_path)
    return state_path


async def _interactive_login(settings: Settings, state_path: Path) -> None:
    log.info("Launching a visible browser for SSO login...")
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(**settings.launch_kwargs(headless=False))
        context = await browser.new_context(
            user_agent=settings.user_agent,
            viewport={"width": settings.viewport_width, "height": settings.viewport_height},
        )
        page = await context.new_page()
        await page.goto(settings.base_url, wait_until="domcontentloaded")

        print("\n" + "=" * 70)
        print("  SSO LOGIN")
        print("  A browser window has opened. Complete your login there.")
        print("  When the documentation is fully visible, come back here")
        print("  and press ENTER to capture the session.")
        print("=" * 70 + "\n")

        # Run the blocking input() off the event loop so Playwright stays alive.
        await asyncio.get_event_loop().run_in_executor(None, input)

        if not await _looks_authenticated(context, settings):
            log.warning(
                "Still seeing a login/redirect URL. Saving state anyway -- "
                "if crawling fails, re-run with --login to try again."
            )

        state_path.parent.mkdir(parents=True, exist_ok=True)
        await context.storage_state(path=str(state_path))
        log.info("Saved authenticated session -> %s", state_path)

        await context.close()
        await browser.close()


def load_cookies_for_aiohttp(state_path: Path) -> dict:
    """
    Extract cookies from a Playwright storage_state file into a simple
    {name: value} dict plus a domain list, for seeding an aiohttp session so
    asset downloads carry the same authentication.
    """
    import json

    if not state_path.exists():
        return {"cookies": [], "domains": []}
    data = json.loads(state_path.read_text(encoding="utf-8"))
    cookies = data.get("cookies", [])
    domains = sorted({c.get("domain", "").lstrip(".") for c in cookies if c.get("domain")})
    return {"cookies": cookies, "domains": domains}
