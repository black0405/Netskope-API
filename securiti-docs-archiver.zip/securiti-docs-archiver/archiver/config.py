"""
config.py
=========
Central configuration for the Securiti Help Center archiver.

All tunables live here. Values can be overridden with environment variables
(prefix ``ARCHIVER_``) or a local ``.env`` file. Nothing sensitive is stored
here -- credentials are entered interactively in the browser during the SSO
login step and are never read by this program.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="ARCHIVER_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ------------------------------------------------------------------ #
    # Target
    # ------------------------------------------------------------------ #
    base_url: str = "https://helpcenter.securiti.ai/docs"
    #: Only URLs whose host matches one of these are treated as "internal"
    #: documentation pages and crawled. Assets may live on other hosts.
    allowed_hosts: List[str] = ["helpcenter.securiti.ai"]
    #: A page URL must contain this path prefix to be crawled as documentation.
    docs_path_prefix: str = "/docs"

    # ------------------------------------------------------------------ #
    # Browser
    # ------------------------------------------------------------------ #
    #: Playwright launch channel. Leave EMPTY ("") to use Playwright's own
    #: bundled Chromium (works everywhere, incl. Kali). Set to "chrome" or
    #: "msedge" ONLY if you have that browser installed as a system channel.
    browser_channel: str = ""
    headless: bool = True
    #: Login always runs headed so you can complete SSO by hand, regardless
    #: of the headless flag above.
    nav_timeout_ms: int = 45_000
    page_load_state: str = "networkidle"  # "load" | "domcontentloaded" | "networkidle"
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
    )
    viewport_width: int = 1440
    viewport_height: int = 2400  # tall viewport helps trigger lazy loads

    # ------------------------------------------------------------------ #
    # Concurrency / performance
    # ------------------------------------------------------------------ #
    #: Number of browser pages (tabs) rendering documentation concurrently.
    page_concurrency: int = 4
    #: Number of concurrent asset (aiohttp) downloads.
    asset_concurrency: int = 12
    #: aiohttp TCP connection-pool size.
    connection_pool_limit: int = 20
    #: Politeness delay (seconds) added after each page render.
    per_page_delay: float = 0.4
    #: Retry policy for network operations.
    max_retries: int = 5
    backoff_base: float = 0.75  # seconds; exponential base
    backoff_max: float = 30.0
    request_timeout: float = 60.0  # aiohttp per-request timeout (seconds)

    # ------------------------------------------------------------------ #
    # Crawl control
    # ------------------------------------------------------------------ #
    #: Safety cap. Set to 0 for unlimited.
    max_pages: int = 0
    #: How many times to sweep the sidebar clicking expanders per page.
    nav_expand_passes: int = 6
    #: Substrings that, if present in a link, cause it to be ignored.
    ignore_url_substrings: List[str] = [
        "logout", "signout", "sign-out", "/login", "/auth",
        "mailto:", "tel:", "javascript:", "#",
    ]
    #: File extensions treated as downloadable assets.
    asset_extensions: List[str] = [
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
        ".pdf", ".zip", ".mp4", ".webm", ".ico",
        ".css", ".woff", ".woff2", ".ttf",
    ]
    #: File extensions saved into the /pdf tree specifically.
    pdf_extensions: List[str] = [".pdf"]
    #: Extensions saved into /images.
    image_extensions: List[str] = [
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico",
    ]

    # ------------------------------------------------------------------ #
    # Output
    # ------------------------------------------------------------------ #
    output_dir: Path = Path("docs")

    # ------------------------------------------------------------------ #
    # Derived paths (computed, not from env)
    # ------------------------------------------------------------------ #
    @property
    def html_dir(self) -> Path:
        return self.output_dir / "html"

    @property
    def markdown_dir(self) -> Path:
        return self.output_dir / "markdown"

    @property
    def json_dir(self) -> Path:
        return self.output_dir / "json"

    @property
    def text_dir(self) -> Path:
        return self.output_dir / "text"

    @property
    def images_dir(self) -> Path:
        return self.output_dir / "images"

    @property
    def assets_dir(self) -> Path:
        return self.output_dir / "assets"

    @property
    def pdf_dir(self) -> Path:
        return self.output_dir / "pdf"

    @property
    def logs_dir(self) -> Path:
        return self.output_dir / "logs"

    @property
    def state_dir(self) -> Path:
        return self.output_dir / "state"

    @property
    def storage_state_path(self) -> Path:
        return self.state_dir / "storage_state.json"

    @property
    def crawl_state_path(self) -> Path:
        return self.state_dir / "crawl_state.json"

    @property
    def index_path(self) -> Path:
        return self.output_dir / "index.html"

    def all_dirs(self) -> List[Path]:
        return [
            self.output_dir, self.html_dir, self.markdown_dir, self.json_dir,
            self.text_dir, self.images_dir, self.assets_dir, self.pdf_dir,
            self.logs_dir, self.state_dir,
        ]

    def ensure_dirs(self) -> None:
        for d in self.all_dirs():
            d.mkdir(parents=True, exist_ok=True)

    def launch_kwargs(self, headless: bool) -> dict:
        """Playwright launch kwargs. Omits ``channel`` entirely when empty so
        the bundled Chromium is used instead of a system browser."""
        kwargs: dict = {"headless": headless}
        if self.browser_channel:
            kwargs["channel"] = self.browser_channel
        return kwargs


# Selectors specific to Document360 (the engine behind the Securiti help
# center). They are best-effort and degrade gracefully if the markup changes.
DOC360_SELECTORS = {
    # Clickable elements that expand a collapsed navigation branch.
    "nav_expanders": [
        "button[aria-expanded='false']",
        ".tree-arrow.collapsed",
        "i.category-arrow.collapsed",
        ".d360-data-list-tree .expand-icon",
        "span.toggle[aria-expanded='false']",
    ],
    # The container that holds the article body once rendered.
    "article_body": [
        "#articleContent",
        ".article-content",
        "main article",
        "div.article-container",
    ],
    # Breadcrumb trail.
    "breadcrumbs": [
        "nav[aria-label='breadcrumb'] a",
        ".breadcrumb a",
        ".breadcrumbs a",
    ],
    # Sidebar navigation link anchors.
    "nav_links": [
        "nav a[href]",
        ".sidebar a[href]",
        "aside a[href]",
        ".category-list a[href]",
    ],
}

# Filesystem-unsafe characters replaced when turning a slug into a filename.
_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def slugify(value: str, fallback: str = "index") -> str:
    """Turn an arbitrary string into a safe filesystem slug."""
    value = value.strip().strip("/")
    value = value.replace("/", "__")
    value = _UNSAFE.sub("-", value).strip("-")
    return value or fallback


settings = Settings()
