"""
crawler.py
==========
Async Playwright crawler.

Renders each documentation page in a real browser (so client-side navigation,
dynamic trees and lazy images all work), expands the Document360 sidebar to
surface every branch, scrolls to trigger lazy loads, then hands the fully
rendered HTML to a caller-supplied handler. New internal links are discovered
and queued automatically; duplicates and external/logout links are skipped.
"""
from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, Set
from urllib.parse import urldefrag, urljoin, urlparse

from bs4 import BeautifulSoup
from playwright.async_api import (
    BrowserContext,
    Error as PlaywrightError,
    Page,
    TimeoutError as PWTimeout,
    async_playwright,
)

from .config import DOC360_SELECTORS, Settings
from .logging_setup import get_logger
from .state import CrawlState

log = get_logger("crawler")

# handler(url, rendered_html) -> awaitable
PageHandler = Callable[[str, str], Awaitable[None]]


class Crawler:
    def __init__(self, settings: Settings, state: CrawlState, storage_state_path: str):
        self.settings = settings
        self.state = state
        self.storage_state_path = storage_state_path
        self.queue: asyncio.Queue[str] = asyncio.Queue()
        self._on_progress: Callable[[], None] | None = None

    # ------------------------------------------------------------------ #
    # URL helpers
    # ------------------------------------------------------------------ #
    def _normalize(self, url: str) -> str:
        url, _ = urldefrag(url)
        return url.rstrip("/") if url.endswith("/") and url.count("/") > 3 else url

    def _is_internal_doc(self, url: str) -> bool:
        try:
            p = urlparse(url)
        except ValueError:
            return False
        if p.scheme not in ("http", "https"):
            return False
        if p.netloc not in self.settings.allowed_hosts:
            return False
        if not p.path.startswith(self.settings.docs_path_prefix):
            return False
        low = url.lower()
        return not any(bad in low for bad in self.settings.ignore_url_substrings)

    # ------------------------------------------------------------------ #
    # Page rendering
    # ------------------------------------------------------------------ #
    async def _expand_navigation(self, page: Page) -> None:
        """Click every collapsed expander in the sidebar, repeatedly."""
        selector = ", ".join(DOC360_SELECTORS["nav_expanders"])
        for _ in range(self.settings.nav_expand_passes):
            handles = await page.query_selector_all(selector)
            if not handles:
                break
            clicked = 0
            for h in handles:
                try:
                    if await h.is_visible():
                        await h.click(timeout=1500)
                        clicked += 1
                        await page.wait_for_timeout(120)
                except (PWTimeout, PlaywrightError):
                    continue
            if clicked == 0:
                break

    async def _trigger_lazy_load(self, page: Page) -> None:
        """Scroll through the page to fire IntersectionObserver-based loaders."""
        try:
            height = await page.evaluate("() => document.body.scrollHeight")
            step = self.settings.viewport_height
            pos = 0
            while pos < height:
                await page.evaluate(f"window.scrollTo(0, {pos})")
                await page.wait_for_timeout(150)
                pos += step
                height = await page.evaluate("() => document.body.scrollHeight")
            await page.evaluate("window.scrollTo(0, 0)")
            await page.wait_for_timeout(200)
        except PlaywrightError:
            pass

    async def _await_content(self, page: Page) -> None:
        """Best-effort wait for the article body to appear after navigation."""
        for sel in DOC360_SELECTORS["article_body"]:
            try:
                await page.wait_for_selector(sel, state="visible", timeout=8000)
                return
            except (PWTimeout, PlaywrightError):
                continue
        # Fall back to waiting for the DOM to settle a little.
        try:
            await page.wait_for_load_state("load", timeout=8000)
        except (PWTimeout, PlaywrightError):
            pass

    async def _render(self, context: BrowserContext, url: str) -> str | None:
        page = await context.new_page()
        try:
            try:
                await page.goto(
                    url,
                    wait_until=self.settings.page_load_state,
                    timeout=self.settings.nav_timeout_ms,
                )
            except PWTimeout:
                # The page is very likely usable; the wait condition just never
                # fired. Continue and capture whatever rendered.
                log.debug("nav wait timed out for %s; continuing", url)

            await self._await_content(page)
            await self._expand_navigation(page)
            await self._trigger_lazy_load(page)
            await page.wait_for_timeout(int(self.settings.per_page_delay * 1000))

            html = await page.content()
            if html and len(html) > 500:
                return html
            log.warning("empty/too-short content for %s", url)
            return None
        except PlaywrightError as exc:
            log.warning("render error %s (%s)", url, exc)
            return None
        finally:
            await page.close()

    # ------------------------------------------------------------------ #
    # Link discovery
    # ------------------------------------------------------------------ #
    def _discover_links(self, html: str, page_url: str) -> Set[str]:
        soup = BeautifulSoup(html, "lxml")
        out: Set[str] = set()
        for a in soup.find_all("a", href=True):
            absolute = self._normalize(urljoin(page_url, a["href"]))
            if self._is_internal_doc(absolute):
                out.add(absolute)
        return out

    # ------------------------------------------------------------------ #
    # Orchestration
    # ------------------------------------------------------------------ #
    async def _worker(self, context: BrowserContext, handler: PageHandler) -> None:
        while True:
            url = await self.queue.get()
            try:
                if self.state.is_completed(url):
                    continue
                if self.settings.max_pages and len(self.state.completed) >= self.settings.max_pages:
                    continue

                html = await self._render(context, url)
                if html is None:
                    self.state.mark_failed(url)
                    continue

                # Discover & enqueue new pages.
                for link in self._discover_links(html, url):
                    if self.state.add_discovered(link) and not self.state.is_completed(link):
                        self.queue.put_nowait(link)

                await handler(url, html)
                self.state.mark_completed(url)
                self.state.flush()
                if self._on_progress:
                    self._on_progress()
            except Exception as exc:  # noqa: BLE001
                log.exception("worker error on %s: %s", url, exc)
                self.state.mark_failed(url)
            finally:
                self.queue.task_done()

    async def run(self, handler: PageHandler, on_progress: Callable[[], None] | None = None) -> None:
        self._on_progress = on_progress
        seed = self._normalize(self.settings.base_url)

        # Seed queue: any discovered-but-not-completed URLs (resume) + the base.
        pending = (self.state.discovered - self.state.completed) | {seed}
        for u in pending:
            if self._is_internal_doc(u) or u == seed:
                self.state.add_discovered(u)
                self.queue.put_nowait(u)

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(
                **self.settings.launch_kwargs(headless=self.settings.headless)
            )
            context = await browser.new_context(
                storage_state=self.storage_state_path,
                user_agent=self.settings.user_agent,
                viewport={
                    "width": self.settings.viewport_width,
                    "height": self.settings.viewport_height,
                },
            )
            workers = [
                asyncio.create_task(self._worker(context, handler))
                for _ in range(self.settings.page_concurrency)
            ]
            await self.queue.join()
            for w in workers:
                w.cancel()
            await asyncio.gather(*workers, return_exceptions=True)
            await context.close()
            await browser.close()
        self.state.flush(force=True)
