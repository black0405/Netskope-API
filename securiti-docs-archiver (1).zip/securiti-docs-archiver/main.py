#!/usr/bin/env python3
"""
main.py
=======
Entry point for the Securiti Help Center archiver.

Pipeline
--------
  1. Ensure an authenticated session (interactive SSO on first run).
  2. Crawl every reachable documentation page (async Playwright).
  3. For each page: save HTML / Markdown / text / JSON and collect assets.
  4. Download all assets concurrently (aiohttp, retry, resume).
  5. Rewrite links for offline viewing and build index.html.

Everything is resumable: re-running continues where it left off.

Usage
-----
    python main.py                       # normal run / resume
    python main.py --login               # force a fresh SSO login
    python main.py --browser msedge      # use Microsoft Edge
    python main.py --no-headless         # watch the crawl
    python main.py --max-pages 25        # smoke test
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Dict, Tuple

from tqdm import tqdm

from archiver.assets import extract_asset_urls, is_downloadable_asset, local_path_for
from archiver.auth import ensure_session, load_cookies_for_aiohttp
from archiver.config import settings
from archiver.crawler import Crawler
from archiver.downloader import Downloader
from archiver.extractor import extract
from archiver.logging_setup import get_logger, setup_logging
from archiver.state import CrawlState
from archiver.writer import finalize_links, write_page_outputs

log = get_logger("main")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Archive the Securiti Help Center for offline use.")
    p.add_argument("--login", action="store_true", help="Force a fresh interactive SSO login.")
    p.add_argument("--browser", choices=["chromium", "chrome", "msedge"],
                   help="Browser to use. 'chromium' (default) = Playwright's bundled build.")
    p.add_argument("--headless", dest="headless", action="store_true", help="Run headless (default).")
    p.add_argument("--no-headless", dest="headless", action="store_false", help="Run with a visible browser.")
    p.set_defaults(headless=None)
    p.add_argument("--output", help="Output directory (default: ./docs).")
    p.add_argument("--base-url", help="Override the docs base URL.")
    p.add_argument("--max-pages", type=int, help="Cap the number of pages (0 = unlimited).")
    p.add_argument("--page-concurrency", type=int, help="Concurrent page renders.")
    p.add_argument("--asset-concurrency", type=int, help="Concurrent asset downloads.")
    p.add_argument("--user-data-dir", help="Reuse an existing browser profile dir (keeps its SSO).")
    p.add_argument("--cdp", help="Attach to a running browser, e.g. http://localhost:9222")
    p.add_argument("--cookies-file", help="Exported cookies (JSON/cookies.txt/header) to import as the session.")
    p.add_argument("--verbose", action="store_true", help="Verbose console logging.")
    return p.parse_args()


def apply_overrides(args: argparse.Namespace) -> None:
    if args.browser:
        settings.browser_channel = "" if args.browser == "chromium" else args.browser
    if args.headless is not None:
        settings.headless = args.headless
    if args.output:
        from pathlib import Path
        settings.output_dir = Path(args.output)
    if args.base_url:
        settings.base_url = args.base_url
    if args.max_pages is not None:
        settings.max_pages = args.max_pages
    if args.page_concurrency:
        settings.page_concurrency = args.page_concurrency
    if args.asset_concurrency:
        settings.asset_concurrency = args.asset_concurrency
    if args.user_data_dir:
        settings.user_data_dir = args.user_data_dir
    if args.cdp:
        settings.cdp_url = args.cdp
    if args.cookies_file:
        settings.cookies_file = args.cookies_file


async def run(args: argparse.Namespace) -> int:
    settings.ensure_dirs()
    setup_logging(settings.logs_dir, verbose=args.verbose)

    log.info("Securiti Help Center archiver starting.")
    log.info("Target: %s | browser=%s | headless=%s",
             settings.base_url, settings.browser_channel, settings.headless)

    # ---- 1. Session -------------------------------------------------- #
    state_path = await ensure_session(settings, force=args.login)
    cookie_bundle = load_cookies_for_aiohttp(state_path)

    # ---- Resume state ------------------------------------------------ #
    state = CrawlState(settings.crawl_state_path)
    state.load()
    if state.completed:
        log.info("Resuming: %d pages already completed.", len(state.completed))

    # Assets discovered during the crawl: url -> (dest, rel)
    asset_targets: Dict[str, Tuple] = {}

    # ---- 2/3. Crawl + per-page outputs ------------------------------- #
    crawl_bar = tqdm(desc="Pages", unit="page", dynamic_ncols=True)

    async def handle_page(url: str, html: str) -> None:
        content = extract(html, url)
        write_page_outputs(content, html, settings, state)
        for a_url in extract_asset_urls(html, url):
            if a_url in asset_targets:
                continue
            if is_downloadable_asset(a_url, settings):
                dest, rel = local_path_for(a_url, settings)
                asset_targets[a_url] = (dest, rel)
        crawl_bar.set_postfix(
            done=len(state.completed), queued=len(state.discovered) - len(state.completed),
            assets=len(asset_targets), refresh=False,
        )

    crawler = Crawler(settings, state, str(state_path))
    await crawler.run(handle_page, on_progress=lambda: crawl_bar.update(1))
    crawl_bar.close()
    log.info("Crawl complete. %s", state.stats())

    # ---- 4. Asset downloads ------------------------------------------ #
    pending = {u: v for u, v in asset_targets.items() if not state.is_asset_done(u)}
    log.info("Downloading %d assets (%d already cached).",
             len(pending), len(asset_targets) - len(pending))

    if pending:
        asset_bar = tqdm(total=len(pending), desc="Assets", unit="file", dynamic_ncols=True)
        async with Downloader(settings, cookie_bundle["cookies"]) as dl:
            async def fetch(u: str, dest, rel: str) -> None:
                ok = await dl.download(u, dest)
                if ok:
                    state.mark_asset_done(u, rel)
                asset_bar.update(1)
                if asset_bar.n % 25 == 0:
                    state.flush()

            await asyncio.gather(*[
                fetch(u, dest, rel) for u, (dest, rel) in pending.items()
            ])
        asset_bar.close()
        state.flush(force=True)

    # ---- 5. Finalize ------------------------------------------------- #
    finalize_links(settings, state)
    state.flush(force=True)

    s = state.stats()
    log.info("DONE. pages=%d failed=%d assets=%d",
             s["completed"], s["failed"], s["assets_done"])
    print("\n" + "=" * 60)
    print(f"  Archive complete -> {settings.output_dir.resolve()}")
    print(f"  Pages: {s['completed']}   Failed: {s['failed']}   Assets: {s['assets_done']}")
    print(f"  Open: {settings.index_path.resolve()}")
    if s["failed"]:
        print(f"  See {settings.logs_dir / 'failures.log'} for failures.")
    print("=" * 60)
    return 0


def main() -> int:
    args = parse_args()
    apply_overrides(args)
    try:
        return asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nInterrupted. Progress saved — re-run to resume.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
