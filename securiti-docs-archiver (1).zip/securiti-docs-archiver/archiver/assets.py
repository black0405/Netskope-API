"""
assets.py
=========
Discover every downloadable asset referenced by a rendered page and compute
deterministic local paths for them (preserving remote folder structure).

Handled reference types:
  * <img src>, srcset, data-src, data-srcset, data-original, lazy variants
  * <source> inside <picture> (src / srcset)
  * <video src>, <video poster>, <source> inside <video>
  * <a href> pointing at asset file extensions (pdf, zip, ...)
  * <link href> stylesheets and icons
  * inline style="background-image:url(...)" and style blocks
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Iterable, Set
from urllib.parse import unquote, urljoin, urlparse

from bs4 import BeautifulSoup

from .config import Settings, slugify

_URL_IN_CSS = re.compile(r"""url\(\s*['"]?([^'")]+)['"]?\s*\)""", re.IGNORECASE)
_LAZY_ATTRS = (
    "data-src", "data-original", "data-lazy-src", "data-url",
    "data-image", "data-bg", "data-background",
)
_SRCSET_ATTRS = ("srcset", "data-srcset", "data-lazy-srcset")


def _split_srcset(value: str) -> Iterable[str]:
    for part in value.split(","):
        url = part.strip().split(" ")[0].strip()
        if url:
            yield url


def extract_asset_urls(html: str, page_url: str) -> Set[str]:
    """Return the set of absolute asset URLs referenced by ``html``."""
    soup = BeautifulSoup(html, "lxml")
    found: Set[str] = set()

    def add(raw: str) -> None:
        if not raw:
            return
        raw = raw.strip()
        if raw.startswith(("data:", "blob:", "javascript:", "#")):
            return
        found.add(urljoin(page_url, raw))

    # <img> and lazy variants
    for img in soup.find_all("img"):
        add(img.get("src", ""))
        for attr in _LAZY_ATTRS:
            add(img.get(attr, ""))
        for attr in _SRCSET_ATTRS:
            if img.get(attr):
                for u in _split_srcset(img[attr]):
                    add(u)

    # <picture><source>
    for src in soup.find_all("source"):
        add(src.get("src", ""))
        for attr in _SRCSET_ATTRS:
            if src.get(attr):
                for u in _split_srcset(src[attr]):
                    add(u)

    # <video>
    for vid in soup.find_all("video"):
        add(vid.get("src", ""))
        add(vid.get("poster", ""))

    # <link> stylesheets / icons / preloads
    for link in soup.find_all("link", href=True):
        rel = " ".join(link.get("rel", [])).lower()
        if any(k in rel for k in ("stylesheet", "icon", "preload", "apple-touch")):
            add(link["href"])

    # <a href> to asset files
    for a in soup.find_all("a", href=True):
        add(a["href"])  # filtered later by extension in local_path_for/classify

    # inline style + <style> blocks -> background images
    for el in soup.find_all(style=True):
        for m in _URL_IN_CSS.finditer(el["style"]):
            add(m.group(1))
    for style in soup.find_all("style"):
        for m in _URL_IN_CSS.finditer(style.get_text() or ""):
            add(m.group(1))

    return found


def is_downloadable_asset(url: str, settings: Settings) -> bool:
    ext = _ext(url)
    return ext in settings.asset_extensions


def _ext(url: str) -> str:
    path = urlparse(url).path
    return Path(unquote(path)).suffix.lower()


def category_dir(url: str, settings: Settings) -> str:
    ext = _ext(url)
    if ext in settings.pdf_extensions:
        return "pdf"
    if ext in settings.image_extensions:
        return "images"
    return "assets"


def local_path_for(url: str, settings: Settings) -> tuple[Path, str]:
    """
    Map a remote asset URL to (absolute_path, relative_path_from_output_dir),
    preserving the host + path folder structure under the category directory.
    """
    parsed = urlparse(url)
    host = slugify(parsed.netloc) or "host"
    raw_path = unquote(parsed.path).lstrip("/")
    if not raw_path:
        raw_path = "index"
    # Keep the directory structure; sanitize each segment.
    segments = [slugify(seg) for seg in raw_path.split("/") if seg]
    if not segments:
        segments = ["index"]
    # Preserve the real extension on the final segment.
    ext = _ext(url)
    if ext and not segments[-1].endswith(ext.replace(".", "-")):
        # slugify may have turned ".png" into "-png"; restore a clean ext.
        base = Path(unquote(parsed.path)).stem
        segments[-1] = f"{slugify(base) or 'file'}{ext}"

    # Cache-busting query strings become part of the filename to avoid clashes.
    if parsed.query:
        q = slugify(parsed.query)[:40]
        stem = Path(segments[-1]).stem
        suffix = Path(segments[-1]).suffix
        segments[-1] = f"{stem}__{q}{suffix}"

    cat = category_dir(url, settings)
    rel = Path(cat) / host / Path(*segments)
    return (settings.output_dir / rel), str(rel).replace(os.sep, "/")
