"""
state.py
========
Durable crawl state so the archiver can resume after an interruption.

Tracks four sets of URLs (discovered / completed / failed / asset-done) plus a
mapping of remote URL -> local relative path used to rewrite links. State is
flushed to disk atomically and periodically.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Dict, Set


class CrawlState:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()
        self.discovered: Set[str] = set()
        self.completed: Set[str] = set()
        self.failed: Set[str] = set()
        self.assets_done: Set[str] = set()
        #: remote URL -> local path relative to output_dir
        self.url_to_local: Dict[str, str] = {}
        self._dirty = 0

    # ------------------------------------------------------------------ #
    # Persistence
    # ------------------------------------------------------------------ #
    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return
        self.discovered = set(data.get("discovered", []))
        self.completed = set(data.get("completed", []))
        self.failed = set(data.get("failed", []))
        self.assets_done = set(data.get("assets_done", []))
        self.url_to_local = dict(data.get("url_to_local", {}))

    def _serialize(self) -> str:
        return json.dumps(
            {
                "discovered": sorted(self.discovered),
                "completed": sorted(self.completed),
                "failed": sorted(self.failed),
                "assets_done": sorted(self.assets_done),
                "url_to_local": self.url_to_local,
            },
            indent=2,
        )

    def flush(self, force: bool = False) -> None:
        with self._lock:
            self._dirty += 1
            if not force and self._dirty % 15 != 0:
                return
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=str(self.path.parent), suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    fh.write(self._serialize())
                os.replace(tmp, self.path)  # atomic on POSIX & Windows
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)

    # ------------------------------------------------------------------ #
    # Mutations (thread/task safe)
    # ------------------------------------------------------------------ #
    def add_discovered(self, url: str) -> bool:
        """Returns True if the URL was newly added."""
        with self._lock:
            if url in self.discovered:
                return False
            self.discovered.add(url)
            return True

    def mark_completed(self, url: str) -> None:
        with self._lock:
            self.completed.add(url)
            self.failed.discard(url)

    def mark_failed(self, url: str) -> None:
        with self._lock:
            self.failed.add(url)

    def mark_asset_done(self, url: str, local: str) -> None:
        with self._lock:
            self.assets_done.add(url)
            self.url_to_local[url] = local

    def register_local(self, url: str, local: str) -> None:
        with self._lock:
            self.url_to_local[url] = local

    def is_completed(self, url: str) -> bool:
        return url in self.completed

    def is_asset_done(self, url: str) -> bool:
        return url in self.assets_done

    def stats(self) -> Dict[str, int]:
        return {
            "discovered": len(self.discovered),
            "completed": len(self.completed),
            "failed": len(self.failed),
            "assets_done": len(self.assets_done),
        }
