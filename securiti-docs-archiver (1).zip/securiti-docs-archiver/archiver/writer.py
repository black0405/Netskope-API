"""
writer.py
=========
Persist per-page outputs and rewrite links for offline viewing.

Flow
----
1. ``write_page_outputs`` runs during the crawl: it saves markdown, clean text,
   metadata JSON, and the rendered HTML (still with absolute URLs), and
   registers the page's local path in the shared crawl state.
2. ``finalize_links`` runs once at the end, after every page and asset is
   known: it rewrites <a> and asset references in each saved HTML file to point
   at local copies, and generates a browsable ``index.html``.
"""
from __future__ import annotations

import json
import os
from html import escape
from pathlib import Path
from typing import Dict, List, Tuple
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from .assets import _LAZY_ATTRS, _SRCSET_ATTRS, _split_srcset
from .config import Settings, slugify
from .extractor import PageContent
from .logging_setup import get_logger
from .state import CrawlState

log = get_logger("writer")


def page_local_path(url: str, settings: Settings) -> Tuple[Path, str]:
    """Deterministic html file path for a documentation page URL."""
    parsed = urlparse(url)
    path = parsed.path
    prefix = settings.docs_path_prefix
    if path.startswith(prefix):
        path = path[len(prefix):]
    slug = slugify(path, fallback="index")
    if parsed.query:
        slug = f"{slug}__{slugify(parsed.query)[:30]}"
    rel = Path("html") / f"{slug}.html"
    return settings.output_dir / rel, str(rel).replace(os.sep, "/")


def write_page_outputs(
    content: PageContent,
    rendered_html: str,
    settings: Settings,
    state: CrawlState,
) -> None:
    # Canonical slug == the html file stem, so JSON/MD/TXT/HTML all align and
    # the index can recover titles reliably.
    html_path, html_rel = page_local_path(content.url, settings)
    slug = Path(html_rel).stem

    # Metadata JSON
    meta = {
        "url": content.url,
        "title": content.title,
        "breadcrumbs": content.breadcrumbs,
        "headings": content.headings,
        "slug": slug,
    }
    (settings.json_dir / f"{slug}.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # Markdown (front-matter + body)
    fm = [
        "---",
        f"title: {content.title}",
        f"url: {content.url}",
        f"breadcrumbs: {' > '.join(content.breadcrumbs)}",
        "---",
        "",
    ]
    (settings.markdown_dir / f"{slug}.md").write_text(
        "\n".join(fm) + content.markdown + "\n", encoding="utf-8"
    )

    # Clean text
    (settings.text_dir / f"{slug}.txt").write_text(
        f"{content.title}\n{content.url}\n\n{content.text}\n", encoding="utf-8"
    )

    # Rendered HTML (absolute URLs for now; rewritten in finalize pass)
    html_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.write_text(rendered_html, encoding="utf-8")

    state.register_local(content.url, html_rel)


def _rewrite_one(html_path: Path, page_url: str, settings: Settings, state: CrawlState) -> int:
    """Rewrite references in a single saved HTML file. Returns #links rewritten."""
    try:
        html = html_path.read_text(encoding="utf-8")
    except OSError:
        return 0
    soup = BeautifulSoup(html, "lxml")
    html_dir = settings.html_dir
    rewritten = 0

    def to_local(remote: str) -> str | None:
        """Return a path relative to this html file, or None if not archived."""
        absolute = urljoin(page_url, remote)
        # Normalize away fragments for lookup.
        base = absolute.split("#", 1)[0]
        frag = absolute[len(base):]
        local_rel = state.url_to_local.get(base)
        if not local_rel:
            return None
        target_abs = settings.output_dir / local_rel
        rel = os.path.relpath(target_abs, start=html_dir).replace(os.sep, "/")
        return rel + frag

    # <a href> -> internal pages
    for a in soup.find_all("a", href=True):
        new = to_local(a["href"])
        if new:
            a["href"] = new
            rewritten += 1

    # <img src> and lazy attrs
    for img in soup.find_all("img"):
        if img.get("src"):
            new = to_local(img["src"])
            if new:
                img["src"] = new
                rewritten += 1
        for attr in _LAZY_ATTRS:
            if img.get(attr):
                new = to_local(img[attr])
                if new:
                    img["src"] = new  # promote lazy attr to real src
                    del img[attr]
                    rewritten += 1
        for attr in _SRCSET_ATTRS:
            if img.get(attr):
                del img[attr]  # remove to avoid the browser refetching remote

    # <source> / <video> / <link>
    for src in soup.find_all("source"):
        if src.get("src"):
            new = to_local(src["src"])
            if new:
                src["src"] = new
                rewritten += 1
        for attr in _SRCSET_ATTRS:
            if src.get(attr):
                del src[attr]
    for vid in soup.find_all("video"):
        for attr in ("src", "poster"):
            if vid.get(attr):
                new = to_local(vid[attr])
                if new:
                    vid[attr] = new
                    rewritten += 1
    for link in soup.find_all("link", href=True):
        new = to_local(link["href"])
        if new:
            link["href"] = new
            rewritten += 1

    html_path.write_text(str(soup), encoding="utf-8")
    return rewritten


def finalize_links(settings: Settings, state: CrawlState) -> None:
    log.info("Rewriting links for offline viewing...")
    total = 0
    # Invert url_to_local for pages to recover each page's html file path.
    for url in sorted(state.completed):
        local_rel = state.url_to_local.get(url)
        if not local_rel or not local_rel.startswith("html/"):
            continue
        html_path = settings.output_dir / local_rel
        if html_path.exists():
            total += _rewrite_one(html_path, url, settings, state)
    log.info("Rewrote %d references across %d pages.", total, len(state.completed))
    _write_index(settings, state)


def _write_index(settings: Settings, state: CrawlState) -> None:
    """Generate a simple browsable index.html linking every archived page."""
    rows: List[str] = []
    entries: List[Tuple[str, str, str]] = []  # (title, rel_html, url)
    for url in sorted(state.completed):
        local_rel = state.url_to_local.get(url)
        if not local_rel or not local_rel.startswith("html/"):
            continue
        # Read title from the matching JSON if available.
        slug = Path(local_rel).stem
        title = slug
        jp = settings.json_dir / f"{slug}.json"
        if jp.exists():
            try:
                title = json.loads(jp.read_text(encoding="utf-8")).get("title", slug)
            except Exception:  # noqa: BLE001
                pass
        entries.append((title, local_rel, url))

    entries.sort(key=lambda e: e[0].lower())
    for title, rel, url in entries:
        rows.append(
            f'<li><a href="{escape(rel)}">{escape(title)}</a> '
            f'<span class="u">{escape(url)}</span></li>'
        )

    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Securiti Help Center — Offline Archive</title>
<style>
  body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif;
         max-width: 900px; margin: 2rem auto; padding: 0 1rem; color: #1a2233; }}
  h1 {{ color: #0b1f3a; }}
  .meta {{ color: #5a6a85; margin-bottom: 1.5rem; }}
  ul {{ list-style: none; padding: 0; }}
  li {{ padding: .45rem 0; border-bottom: 1px solid #eef1f6; }}
  a {{ color: #0a7d8c; text-decoration: none; font-weight: 600; }}
  a:hover {{ text-decoration: underline; }}
  .u {{ display:block; font-size:.78rem; color:#9aa7bd; font-weight:400; }}
</style></head><body>
<h1>Securiti Help Center — Offline Archive</h1>
<p class="meta">{len(entries)} pages archived.</p>
<ul>
{chr(10).join(rows)}
</ul>
</body></html>"""
    settings.index_path.write_text(html, encoding="utf-8")
    log.info("Wrote index: %s", settings.index_path)
