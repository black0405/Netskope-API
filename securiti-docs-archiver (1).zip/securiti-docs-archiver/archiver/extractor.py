"""
extractor.py
============
Turn a rendered page's HTML into structured outputs:
  * metadata (title, url, breadcrumbs, headings)
  * markdown (via markdownify, scoped to the article body when detectable)
  * clean plain text

Uses the Document360 selectors from config to locate the article body, falling
back to <main>/<body> so it still works on non-Document360 pages.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional
from urllib.parse import urlparse

from bs4 import BeautifulSoup
from markdownify import markdownify as md_convert

from .config import DOC360_SELECTORS


@dataclass
class PageContent:
    url: str
    title: str
    breadcrumbs: List[str] = field(default_factory=list)
    headings: List[str] = field(default_factory=list)
    markdown: str = ""
    text: str = ""
    slug: str = ""


def _first_matching(soup: BeautifulSoup, selectors: List[str]):
    for sel in selectors:
        el = soup.select_one(sel)
        if el:
            return el
    return None


def _extract_title(soup: BeautifulSoup) -> str:
    for sel in ("h1", "article h1", "title"):
        el = soup.select_one(sel)
        if el and el.get_text(strip=True):
            return el.get_text(strip=True)
    return "Untitled"


def _extract_breadcrumbs(soup: BeautifulSoup) -> List[str]:
    for sel in DOC360_SELECTORS["breadcrumbs"]:
        els = soup.select(sel)
        if els:
            crumbs = [e.get_text(strip=True) for e in els if e.get_text(strip=True)]
            if crumbs:
                return crumbs
    return []


def _slug_from_url(url: str) -> str:
    path = urlparse(url).path.strip("/")
    if not path:
        return "index"
    return path.split("/")[-1] or "index"


def extract(html: str, url: str) -> PageContent:
    soup = BeautifulSoup(html, "lxml")

    # Strip obviously non-content chrome from the markdown/text conversion.
    body = _first_matching(soup, DOC360_SELECTORS["article_body"])
    scope = body or soup.find("main") or soup.body or soup

    # Copy the scope so we can prune without harming the saved raw HTML.
    scope_copy = BeautifulSoup(str(scope), "lxml")
    for junk in scope_copy.select("script, style, noscript, nav, header, footer"):
        junk.decompose()

    title = _extract_title(soup)
    breadcrumbs = _extract_breadcrumbs(soup)
    headings = [
        h.get_text(strip=True)
        for h in scope_copy.select("h1, h2, h3, h4")
        if h.get_text(strip=True)
    ]

    markdown = md_convert(
        str(scope_copy),
        heading_style="ATX",
        strip=["script", "style"],
    ).strip()

    text = scope_copy.get_text("\n", strip=True)

    return PageContent(
        url=url,
        title=title,
        breadcrumbs=breadcrumbs,
        headings=headings,
        markdown=markdown,
        text=text,
        slug=_slug_from_url(url),
    )
