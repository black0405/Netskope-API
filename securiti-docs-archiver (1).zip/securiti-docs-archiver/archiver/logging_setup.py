"""
logging_setup.py
================
Configures a rotating file logger plus a clean console logger. The console
handler is quiet (INFO+, no tracebacks) so progress bars stay readable; the
file handler is verbose (DEBUG) and keeps full tracebacks for troubleshooting.
"""
from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

_CONFIGURED = False


def setup_logging(logs_dir: Path, verbose: bool = False) -> logging.Logger:
    global _CONFIGURED
    logs_dir.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger("archiver")
    if _CONFIGURED:
        return root

    root.setLevel(logging.DEBUG)
    root.propagate = False

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = RotatingFileHandler(
        logs_dir / "archiver.log",
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)

    # A dedicated file that only records failures/missing assets.
    fail_handler = RotatingFileHandler(
        logs_dir / "failures.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    fail_handler.setLevel(logging.WARNING)
    fail_handler.setFormatter(fmt)

    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(logging.Formatter("%(levelname)-7s %(message)s"))

    root.addHandler(file_handler)
    root.addHandler(fail_handler)
    root.addHandler(console)

    _CONFIGURED = True
    return root


def get_logger(name: str = "archiver") -> logging.Logger:
    return logging.getLogger(name if name.startswith("archiver") else f"archiver.{name}")
