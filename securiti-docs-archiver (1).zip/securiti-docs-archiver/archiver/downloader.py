"""
downloader.py
=============
Concurrent, resumable asset downloading over aiohttp.

Features
--------
* Shared connection pool (aiohttp TCPConnector).
* Cookie injection so authenticated assets download correctly.
* Exponential-backoff retry via tenacity.
* Skip-if-exists caching (atomic temp-file writes).
* Bounded concurrency via an asyncio.Semaphore.
"""
from __future__ import annotations

import asyncio
import os
import tempfile
from http.cookies import SimpleCookie
from pathlib import Path
from typing import Optional

import aiohttp
from yarl import URL
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from .config import Settings
from .logging_setup import get_logger

log = get_logger("downloader")


class RetryableHTTPError(Exception):
    """Raised for 429/5xx responses so tenacity retries them."""


class Downloader:
    def __init__(self, settings: Settings, cookies: Optional[list] = None):
        self.settings = settings
        self._cookies = cookies or []
        self._session: Optional[aiohttp.ClientSession] = None
        self._sem = asyncio.Semaphore(settings.asset_concurrency)

    async def __aenter__(self) -> "Downloader":
        connector = aiohttp.TCPConnector(
            limit=self.settings.connection_pool_limit,
            limit_per_host=self.settings.connection_pool_limit,
            ttl_dns_cache=300,
            enable_cleanup_closed=True,
        )
        jar = aiohttp.CookieJar()
        # Seed the cookie jar from the Playwright storage state.
        for c in self._cookies:
            try:
                sc = SimpleCookie()
                name = c["name"]
                sc[name] = c["value"]
                domain = c.get("domain", "").lstrip(".")
                sc[name]["domain"] = domain
                sc[name]["path"] = c.get("path", "/")
                jar.update_cookies(sc, response_url=URL(f"https://{domain}"))
            except Exception:  # noqa: BLE001
                continue
        timeout = aiohttp.ClientTimeout(total=self.settings.request_timeout)
        self._session = aiohttp.ClientSession(
            connector=connector,
            cookie_jar=jar,
            timeout=timeout,
            headers={"User-Agent": self.settings.user_agent},
        )
        return self

    async def __aexit__(self, *exc) -> None:
        if self._session:
            await self._session.close()

    async def download(self, url: str, dest: Path) -> bool:
        """
        Download ``url`` to ``dest``. Returns True on success (or if already
        cached). Never raises -- failures are logged and reported as False.
        """
        if dest.exists() and dest.stat().st_size > 0:
            log.debug("cache hit: %s", dest)
            return True

        async with self._sem:
            try:
                await self._download_with_retry(url, dest)
                return True
            except Exception as exc:  # noqa: BLE001
                log.warning("asset FAILED %s (%s)", url, exc)
                return False

    @retry(
        reraise=True,
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=0.75, max=30),
        retry=retry_if_exception_type(
            (RetryableHTTPError, aiohttp.ClientError, asyncio.TimeoutError)
        ),
    )
    async def _download_with_retry(self, url: str, dest: Path) -> None:
        assert self._session is not None
        async with self._session.get(url, allow_redirects=True) as resp:
            if resp.status in (429,) or resp.status >= 500:
                raise RetryableHTTPError(f"HTTP {resp.status} for {url}")
            if resp.status >= 400:
                # 4xx (other than 429) is not worth retrying.
                raise RuntimeError(f"HTTP {resp.status} for {url}")

            dest.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=str(dest.parent), suffix=".part")
            try:
                with os.fdopen(fd, "wb") as fh:
                    async for chunk in resp.content.iter_chunked(64 * 1024):
                        fh.write(chunk)
                os.replace(tmp, dest)
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
        log.debug("downloaded %s -> %s", url, dest)
