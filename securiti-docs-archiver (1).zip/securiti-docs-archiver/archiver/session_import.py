"""
session_import.py
=================
Build a Playwright ``storage_state.json`` from cookies you exported out of a
browser where you're ALREADY logged in. This sidesteps SSO entirely -- useful
when conditional access blocks automated browsers.

Accepted inputs (auto-detected):
  1. JSON array exported by the "Cookie-Editor" / "EditThisCookie" extensions.
  2. A Netscape-format cookies.txt file.
  3. A raw Cookie header string ("a=1; b=2"), with --cookie-domain supplied.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from .logging_setup import get_logger

log = get_logger("session_import")

_SAMESITE_MAP = {
    "no_restriction": "None",
    "none": "None",
    "lax": "Lax",
    "strict": "Strict",
    "unspecified": "Lax",
    "": "Lax",
}


def _norm_samesite(value: Optional[str]) -> str:
    if not value:
        return "Lax"
    return _SAMESITE_MAP.get(str(value).lower(), "Lax")


def _from_extension_json(data: list, default_domain: str) -> List[dict]:
    cookies = []
    for c in data:
        name = c.get("name")
        if not name:
            continue
        domain = c.get("domain") or default_domain
        expires = c.get("expirationDate") or c.get("expires") or -1
        try:
            expires = int(float(expires))
        except (TypeError, ValueError):
            expires = -1
        cookies.append({
            "name": name,
            "value": c.get("value", ""),
            "domain": domain,
            "path": c.get("path", "/"),
            "expires": expires,
            "httpOnly": bool(c.get("httpOnly", False)),
            "secure": bool(c.get("secure", True)),
            "sameSite": _norm_samesite(c.get("sameSite")),
        })
    return cookies


def _from_netscape(text: str) -> List[dict]:
    cookies = []
    for line in text.splitlines():
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) != 7:
            continue
        domain, _flag, path, secure, expires, name, value = parts
        try:
            expires = int(expires)
        except ValueError:
            expires = -1
        cookies.append({
            "name": name, "value": value, "domain": domain, "path": path,
            "expires": expires, "httpOnly": False,
            "secure": secure.upper() == "TRUE", "sameSite": "Lax",
        })
    return cookies


def _from_header(header: str, domain: str) -> List[dict]:
    cookies = []
    for pair in header.split(";"):
        pair = pair.strip()
        if "=" not in pair:
            continue
        name, value = pair.split("=", 1)
        cookies.append({
            "name": name.strip(), "value": value.strip(), "domain": domain,
            "path": "/", "expires": -1, "httpOnly": False,
            "secure": True, "sameSite": "Lax",
        })
    return cookies


def build_storage_state(
    source: Path,
    out_path: Path,
    default_domain: str = "helpcenter.securiti.ai",
) -> int:
    """
    Parse ``source`` (any supported format) and write a Playwright
    storage_state file to ``out_path``. Returns the number of cookies written.
    """
    raw = source.read_text(encoding="utf-8").strip()
    cookies: List[dict]

    if raw.startswith("[") or raw.startswith("{"):
        data = json.loads(raw)
        if isinstance(data, dict) and "cookies" in data:
            # Already a storage_state-like object.
            cookies = data["cookies"]
        else:
            cookies = _from_extension_json(data, default_domain)
    elif "\t" in raw and "\n" in raw:
        cookies = _from_netscape(raw)
    else:
        cookies = _from_header(raw, default_domain)

    if not cookies:
        raise ValueError("No cookies parsed from the source file.")

    storage_state = {"cookies": cookies, "origins": []}
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(storage_state, indent=2), encoding="utf-8")
    log.info("Imported %d cookies -> %s", len(cookies), out_path)
    return len(cookies)
