# Securiti Help Center — Offline Archiver

A production-grade, resumable archiver that logs into the
[Securiti Help Center](https://helpcenter.securiti.ai/docs) with **your own SSO
account**, crawls every reachable documentation page, and saves a complete
offline copy: rendered HTML, Markdown, clean text, metadata JSON, and every
referenced asset (images, SVGs, GIFs, PDFs, attachments), with internal links
rewritten so the archive browses offline.

It authenticates as **you** and never bypasses access controls — the browser
does the login exactly as you would by hand, and the saved session is reused.

---

## Features

- **Async Playwright** rendering (Chrome or Edge) so dynamic nav trees, SPA
  routing, and lazy-loaded images all resolve.
- **Interactive SSO** login once, session reused headlessly thereafter.
- **Concurrent crawling** and **concurrent asset downloads** with connection
  pooling, retries, and exponential backoff.
- **Fully resumable** — interrupt any time; re-run to continue.
- **Skip-existing caching** so re-runs are cheap.
- Saves per page: `html/`, `markdown/`, `text/`, `json/`.
- Downloads assets into `images/`, `pdf/`, `assets/`, preserving folder
  structure, and rewrites references to local copies.
- Generates a browsable `index.html`.
- Detailed rotating logs (`logs/archiver.log`, `logs/failures.log`).

---

## Project layout

```
securiti-docs-archiver/
├── main.py                 # entry point / orchestration
├── requirements.txt
├── README.md
└── archiver/
    ├── config.py           # all settings (env-overridable) + selectors
    ├── logging_setup.py     # rotating file + console logging
    ├── auth.py             # SSO login + session persistence
    ├── state.py            # resume state (atomic, periodic flush)
    ├── crawler.py          # async Playwright crawl + nav expansion
    ├── extractor.py        # metadata / markdown / clean text
    ├── assets.py           # asset discovery + local path mapping
    ├── downloader.py       # aiohttp concurrent downloads + retry
    └── writer.py           # outputs, link rewriting, index.html
```

Output is written under `docs/` by default:

```
docs/
├── index.html
├── html/        markdown/     text/       json/
├── images/      pdf/          assets/
├── logs/        state/storage_state.json  state/crawl_state.json
```

---

## Installation

Requires **Python 3.10+** and Google Chrome and/or Microsoft Edge installed.

```bash
# 1. Clone / unzip, then enter the folder
cd securiti-docs-archiver

# 2. Virtual environment
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows (PowerShell)
.venv\Scripts\Activate.ps1

# 3. Dependencies
pip install -r requirements.txt

# 4. Playwright browser bindings (uses your installed Chrome/Edge channel)
python -m playwright install chromium
```

> The tool launches your **installed** Chrome/Edge via Playwright's `channel`
> option. `playwright install chromium` provides the driver bindings.

---

## Running

```bash
# Normal run (first run triggers interactive login, then crawls)
python main.py

# Force a fresh SSO login (e.g. session expired)
python main.py --login

# Use Microsoft Edge instead of Chrome
python main.py --browser msedge

# Watch it work (visible browser)
python main.py --no-headless

# Quick smoke test — only the first 25 pages
python main.py --max-pages 25

# Tune throughput
python main.py --page-concurrency 6 --asset-concurrency 16

# Custom output directory
python main.py --output ./securiti-archive
```

All flags can also be set via environment variables with the `ARCHIVER_`
prefix, or a `.env` file, e.g.:

```
ARCHIVER_BROWSER_CHANNEL=msedge
ARCHIVER_PAGE_CONCURRENCY=6
ARCHIVER_ASSET_CONCURRENCY=16
ARCHIVER_OUTPUT_DIR=./securiti-archive
```

---

## Login (how SSO works here)

1. On the first run (or `--login`), a **visible** browser window opens at the
   docs site.
2. Complete your normal SSO login in that window (SSO providers vary — Okta,
   Azure AD, Google, etc.; all work because you log in by hand).
3. When the documentation is fully visible, return to the terminal and press
   **ENTER**.
4. The authenticated session (cookies + local storage) is saved to
   `docs/state/storage_state.json`.
5. Every later run reuses that session **headlessly** — no repeated logins
   until the session actually expires.

Credentials are **never** read, stored, or transmitted by this program. Only
the resulting browser session state is saved locally, on your machine.

---

## Resuming

Progress is saved continuously to `docs/state/crawl_state.json`:

- Completed pages are skipped on re-run.
- Already-downloaded assets are skipped (cache hit).
- Interrupt with `Ctrl-C` any time; just run `python main.py` again to
  continue.

To start completely fresh, delete the output directory (or just
`docs/state/crawl_state.json` to re-crawl while keeping downloaded files).

---

## Troubleshooting

**"Saved session appears expired / bounced to a login URL"**
Run `python main.py --login` to re-authenticate.

**Browser channel not found (`chrome`/`msedge`)**
Install the browser, or switch channel: `--browser msedge` (or `chrome`). You
can also fall back to the bundled Chromium by editing `browser_channel` — set it
empty in `config.py` to use Playwright's own Chromium.

**Timeouts on heavy pages**
Increase `ARCHIVER_NAV_TIMEOUT_MS` (e.g. `60000`) or lower
`--page-concurrency`.

**Some images missing offline**
Check `logs/failures.log`. Lazy images behind unusual loaders may need an extra
attribute added to `_LAZY_ATTRS` in `archiver/assets.py`. Assets that fail to
download keep their original absolute URL, so they still load when online.

**Rate limiting (HTTP 429) / 5xx**
These are retried automatically with exponential backoff. If persistent, lower
`--asset-concurrency` and `--page-concurrency`, and raise `per_page_delay` in
`config.py`.

**Nav tree not fully expanded**
The Document360 expander selectors live in `DOC360_SELECTORS["nav_expanders"]`
in `config.py`. If the markup differs, add the relevant selector and re-run;
the crawl will pick up newly revealed pages.

---

## Notes on scope & etiquette

- The crawler only follows **internal** links under the docs path; external
  sites and logout links are ignored.
- Concurrency defaults are conservative. Keep them reasonable so the archive is
  gentle on the server.
- Use this only against documentation you're entitled to access with your own
  account.
